
    <?php

        //Datos de conexión a la BD
        define('DB_SERVER','localhost');
        define('DB_USER','jerr'); //uwhatmas - root - phpmyadmin
        define('DB_PASSWORD','123456789'); //wps0luc10n35* - '' - usuario - whatmas
        define('DB_DATABASE','ivan');//whatmas - velotax_messages



